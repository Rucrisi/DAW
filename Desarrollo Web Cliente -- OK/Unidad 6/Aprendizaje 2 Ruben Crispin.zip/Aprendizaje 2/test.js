// Incluimos un polyfill para Promise
if (!window.Promise) {
    document.write('<script src="https://cdn.jsdelivr.net/npm/promise-polyfill/dist/polyfill.min.js"><\/script>');
}
