<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Consulta IP</title>
</head>
<body>
    <h1>Consultar información sobre una IP</h1>
    <form action="consulta.php" method="POST">
        <label for="ip">Introduce una dirección IP:</label>
        <input type="text" id="ip" name="ip" required>
        <button type="submit">Consultar</button>
    </form>
</body>
</html>
