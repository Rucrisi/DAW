function cambiarContenido() {
    // Seleccionamos el elemento con id "titulo"
    var titulo = document.getElementById("titulo");

    // Cambiamos el contenido del elemento
    titulo.innerHTML = "Título Modificado";
}
